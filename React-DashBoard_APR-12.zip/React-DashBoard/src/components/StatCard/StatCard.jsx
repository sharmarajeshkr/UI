import './StatCard.css';

const StatCard = ({ label, value, icon, footer }) => (
  <div className="dashboard-card">
    <div className="stat-icon">{icon}</div>
    <div className="stat-info">
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
    </div>
    <div className="stat-footer">{footer}</div>
  </div>

 



);

export default StatCard;
