import { Router } from '@angular/router';
import { Component } from '@angular/core';
import { AuthService } from './services/auth.service';
import { UserService } from './services/user.service';
import { UserDetails } from '../environments/userData';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ecommShop';
  juser;
  constructor(private authService : AuthService,
              router : Router,
              private userService : UserService){
                console.log('calling App Comp ts - constr')
    authService.user$.subscribe(user => {
      if (user){
        
        this.juser = UserDetails.details;
        
        let returnUrl = localStorage.getItem('returnUrl')
        console.log(this.juser)
        router.navigateByUrl[returnUrl]
      }
    });
  }


}
