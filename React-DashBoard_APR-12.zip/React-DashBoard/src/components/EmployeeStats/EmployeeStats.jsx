import './EmployeeStats.css';

const EmployeeStats = () => (
  <div className="employee-stats">
    <h3>Employees Stats</h3>
    <p>New employees on 15th September, 2016</p>
  </div>
);

export default EmployeeStats;
