import { UserService } from './user.service';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import * as firebase from 'firebase'

import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';



@Injectable()
export class AuthService {

  user$ : Observable<firebase.User>;
  appUser;
  constructor(private afAuth : AngularFireAuth,
              private route : ActivatedRoute,
              private userService : UserService) {
    this.user$ = afAuth.authState;
   }

  login(){
    
    console.log("calling login")
    console.log('Getting retured value from url')
    let returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || '/';
    console.log('****')
    localStorage.setItem('returnURL',returnUrl);

    this.afAuth.signInWithRedirect(new firebase.auth.GoogleAuthProvider())
  }

  logout(){
    console.log("calling Logout Method")
    this.afAuth.signOut();
  }

  getAppUser(){
    this.userService.getUser()
      .subscribe(user =>{
        this.appUser = user;
      })
    
  }

}
