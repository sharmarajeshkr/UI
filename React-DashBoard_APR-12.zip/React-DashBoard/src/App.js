import { useState } from 'react';

import Sidebar from './components/Sidebar/Sidebar';
import StatCard from './components/StatCard/StatCard';
import ChartCard from './components/ChartCard/ChartCard';
import TaskCard from './components/TaskCard/TaskCard';
import EmployeeStats from './components/EmployeeStats/EmployeeStats';
import EditableTableWithForm  from './components/tables/EditableTableWithForm';

import { ToastContainer } from 'react-toastify';

import UsersTable from './components/tables/userTable/UsersTable';
import ProductsTable from './components/tables/productsTable/ProductsTable';

import 'react-toastify/dist/ReactToastify.css';
import './App.css';

function App() {
  const [activeView, setActiveView] = useState('dashboard');
  return (
    <div className="app-layout">
      <Sidebar setActiveView={setActiveView} />
      
      <main className="main-content">
      {activeView === 'table' && <EditableTableWithForm  />}         

      {activeView === 'dashboard' && (
      <div>
        <div className="dashboard-container">
          <StatCard label="Used Space" value="49/50 GB" footer="Get more space" />
          <StatCard label="Revenue" value="$34,245" footer="Last 24 Hours" />
          <StatCard label="Fixed Issues" value="75" footer="Tracked from GitHub" />
          <StatCard label="Followers" value="+245" footer="Just Updated" />
          <StatCard label="Used Space" value="49/50 GB" footer="Get more space" />
          <StatCard label="Revenue" value="$34,245" footer="Last 24 Hours" />
        </div>

        <div className="dashboard-container">
          <ChartCard title="Daily Sales" chartType="Line" />
          <ChartCard title="Email Subscriptions" chartType="Bar" />
          <ChartCard title="Completed Tasks" chartType="Line" />
        </div>

        <div className="bottom-row">
          <TaskCard />
          <EmployeeStats />
        </div>
      
      </div>
      )}        
      </main>
      
      <ToastContainer
          position="top-right"
          autoClose={2000}
          hideProgressBar={false}
          newestOnTop
          pauseOnFocusLoss
          draggable
          pauseOnHover
      />
    </div>
  );
}

export default App;
