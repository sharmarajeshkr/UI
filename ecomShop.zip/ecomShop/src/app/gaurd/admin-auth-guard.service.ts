
import { AuthService } from './../services/auth.service';
import { UserService } from './../services/user.service';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class AdminAuthGuard implements CanActivate {

  constructor(private userService : UserService , private auth : AuthService) { }
  
  canActivate() : Observable<boolean>{
  return  this.userService.getUser()
    .pipe(map(user => {
      if(user.isAdmin) return true;
      return false;
      
    })
    )
  }
}
