import React, { useState } from 'react';
import './Sidebar.css';


const Sidebar = ({ setActiveView }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  const menuItems = [
    { name: 'Dashboard', key: 'dashboard', icon: '🏠' },
    { name: 'Table', key: 'table', icon: '📋' },
  ];

  return (
    <div className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <button className="toggle-btn" onClick={toggleSidebar}>
        {isCollapsed ? '☰' : '×'}
      </button>

      <h2 className="logo">{!isCollapsed ? 'CREATIVE TIM' : 'CT'}</h2>

      
      <ul>
        {menuItems.map((item, index) => (
          <li key={index} onClick={() => setActiveView(item.key)}>
            {isCollapsed ? item.icon : item.name}
          </li>
        ))}
      </ul>
      
    </div>
  );
};

export default Sidebar;
