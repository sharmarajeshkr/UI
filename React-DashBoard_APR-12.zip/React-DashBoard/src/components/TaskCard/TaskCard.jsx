import './TaskCard.css';

const TaskCard = () => (
  <div className="task-card">
    <div className="task-tabs">
      <span className="active-tab">BUGS</span>
      <span>WEBSITE</span>
      <span>SERVER</span>
    </div>
    <ul>
      <li>☑ Sign contract for "What are conference organizers afraid of?"</li>
    </ul>
  </div>
);

export default TaskCard;
