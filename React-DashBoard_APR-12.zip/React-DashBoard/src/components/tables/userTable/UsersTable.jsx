import React, { useMemo, useState } from 'react';
import { useTable } from 'react-table';
import { toast } from 'react-toastify';
import '../TableView.css';

const UsersTable = () => {
  const [data, setData] = useState([
    { id: 1, name: 'Alice', role: 'Developer' },
    { id: 2, name: 'Bob', role: 'Designer' },
    { id: 3, name: 'Charlie', role: 'Manager' },
  ]);

  const [editingRowId, setEditingRowId] = useState(null);
  const [editedRow, setEditedRow] = useState({});

  const handleDelete = (id) => {
    setData((prev) => prev.filter((row) => row.id !== id));
    toast.error(`Row #${id} deleted`);
  };

 
  const handleEdit = (row) => {
    console.log(row.id);
    setEditingRowId(row.id);
    setEditedRow({ ...row });
    toast.info(`Editing row #${row.id}`);
  };

  const handleSave = () => {
    setData((prev) =>
      prev.map((row) => (row.id === editedRow.id ? editedRow : row))
    );
    toast.success(`Row #${editedRow.id} updated`);
    setEditingRowId(null);
    setEditedRow({});
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedRow((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleAdd = () => {
    const name = prompt('Enter name:');
    const role = prompt('Enter role:');
    if (name && role) {
      const newId = Date.now();
      setData([...data, { id: newId, name, role }]);
    }
  };

  const columns = useMemo(
    () => [
      { Header: 'ID', accessor: 'id' },
      {
        Header: 'Name',
        accessor: 'name',
        Cell: ({ row }) =>
          row.original.id === editingRowId ? (
            <input
              name="name"
              value={editedRow.name}
              onChange={handleChange}
            />
          ) : (
            row.original.name
          ),
      },
      {
        Header: 'Role',
        accessor: 'role',
        Cell: ({ row }) =>
          row.original.id === editingRowId ? (
            <input
              name="role"
              value={editedRow.role}
              onChange={handleChange}
            />
          ) : (
            row.original.role
          ),
      },
      {
        Header: 'Edit',
        Cell: ({ row }) =>
          row.original.id === editingRowId ? (
            <button onClick={handleSave}>Save</button>
          ) : (
            <div className="action-buttons">
              <button onClick={() => handleEdit(row.original)}>Edit</button>              
            </div>
          ),
      },
      {
        Header: 'Delete',
        Cell: ({ row }) =>
          row.original.id === editingRowId ? (
            <button onClick={handleSave}>Save</button>
          ) : (
            <div className="action-buttons">              
              <button onClick={() => handleDelete(row.original.id)}>Delete</button>              
            </div>
          ),
      },
    ],
    [editingRowId, editedRow]
  );

  const tableInstance = useTable({ columns, data });

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = tableInstance;

  

  return (
    <div className="table-container">      
      <h2>Table List</h2>
      <button className="add-btn" onClick={handleAdd}>
        + Add Row
      </button>
      
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map((headerGroup, hIdx) => (
            <tr {...headerGroup.getHeaderGroupProps()} key={hIdx}>
              {headerGroup.headers.map((column, cIdx) => (
                <th {...column.getHeaderProps()} key={cIdx}>
                  {column.render('Header')}
                </th>
              ))}
            </tr>
          ))}
        </thead>

        <tbody {...getTableBodyProps()}>
          {rows.map((row, rIdx) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()} key={rIdx}>
                {row.cells.map((cell, cellIdx) => (
                  <td {...cell.getCellProps()} key={cellIdx}>
                    {cell.render('Cell')}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default UsersTable;
  