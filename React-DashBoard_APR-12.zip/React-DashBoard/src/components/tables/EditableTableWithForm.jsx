import React, { useMemo, useState } from 'react';
import { useTable } from 'react-table';
import { toast } from 'react-toastify';

const EditableTableWithForm = () => {
  const initialData = [
    { id: 1, name: 'Alice', role: 'Developer' },
    { id: 2, name: 'Bob', role: 'Designer' },
    { id: 3, name: 'Charlie', role: 'Manager' },
  ];

  const [data, setData] = useState(initialData);
  const [editFormData, setEditFormData] = useState(null); // For top edit form

  // Handle Edit button click
  const handleEditClick = (rowData) => {
    setEditFormData({ ...rowData });
    toast.info(`Editing row ID ${rowData.id}`);
  };

  // Handle input change in edit form
  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setEditFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Save edited form data
  const handleFormSave = () => {
    setData((prev) =>
      prev.map((item) =>
        item.id === editFormData.id ? editFormData : item
      )
    );
    toast.success(`Row ID ${editFormData.id} updated`);
    setEditFormData(null);
  };

  // Delete a row
  const handleDelete = (id) => {
    setData(data.filter((row) => row.id !== id));
    toast.error(`Row ID ${id} deleted`);
  };

  const columns = useMemo(
    () => [
      { Header: 'ID', accessor: 'id' },
      { Header: 'Name', accessor: 'name' },
      { Header: 'Role', accessor: 'role' },
      {
        Header: 'Edit',
        Cell: ({ row }) => (
          <>
            <button onClick={() => handleEditClick(row.original)}>Edit</button>{' '}            
          </>
        ),
      },
      {
        Header: 'Delete',
        Cell: ({ row }) => (
          <>            
            <button onClick={() => handleDelete(row.original.id)}>Delete</button>
          </>
        ),
      },
    ],
    [data]
  );

  const tableInstance = useTable({ columns, data });

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = tableInstance;

  return (
    <div className="table-with-form">
      <h2>User Management</h2>

      {/* 👆 Edit Form Above Table */}
      {editFormData && (
        <div className="edit-form">
          <h4>Edit User</h4>
          <input
            type="text"
            name="name"
            value={editFormData.name}
            onChange={handleFormChange}
            placeholder="Name"
          />
          <input
            type="text"
            name="role"
            value={editFormData.role}
            onChange={handleFormChange}
            placeholder="Role"
          />
          <button onClick={handleFormSave}>Save</button>
          <button onClick={() => setEditFormData(null)}>Cancel</button>
        </div>
      )}

      {/* 📋 React Table */}
      <table {...getTableProps()} style={{ width: '100%', marginTop: '20px' }}>
        <thead>
          {headerGroups.map((headerGroup, idx) => (
            <tr {...headerGroup.getHeaderGroupProps()} key={idx}>
              {headerGroup.headers.map((col, cidx) => (
                <th {...col.getHeaderProps()} key={cidx}>
                  {col.render('Header')}
                </th>
              ))}
            </tr>
          ))}
        </thead>

        <tbody {...getTableBodyProps()}>
          {rows.map((row, idx) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()} key={idx}>
                {row.cells.map((cell, cid) => (
                  <td {...cell.getCellProps()} key={cid}>
                    {cell.render('Cell')}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default EditableTableWithForm;
