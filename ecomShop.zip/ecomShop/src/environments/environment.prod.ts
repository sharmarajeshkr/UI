export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyAz_RdGU8_KTf1nGZyOoDyH7h760VR9Kic",
    authDomain: "ecom-b2958.firebaseapp.com",
    databaseURL: "https://ecom-b2958.firebaseio.com",
    projectId: "ecom-b2958",
    storageBucket: "ecom-b2958.appspot.com",
    messagingSenderId: "875746919072"
  }
};