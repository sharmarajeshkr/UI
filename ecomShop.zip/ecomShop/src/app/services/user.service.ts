import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { HttpClient } from '@angular/common/http'


@Injectable()
export class UserService {

  constructor(private firestore: AngularFirestore,
              private http : HttpClient) { }
  
  createUser(user: firebase.User){
    return this.firestore.collection('users').add(user.uid);
  }

  getUser():Observable<any>{
    return this.http.get('./assets/json/user.json')
  }


}
