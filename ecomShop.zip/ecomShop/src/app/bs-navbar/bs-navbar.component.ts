import { UserService } from './../services/user.service';
import { Component, OnInit } from '@angular/core';
import * as firebase from 'firebase'
import { AngularFireAuth } from  "@angular/fire/auth";
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'bs-navbar',
  templateUrl: './bs-navbar.component.html',
  styleUrls: ['./bs-navbar.component.css']
})
export class BsNavbarComponent implements OnInit {

  // user$ : Observable<firebase.User>;
  constructor(public authService : AuthService,private userService : UserService) { 
    //this.user$ = afAuth.authState;    
  // afAuth.authState.subscribe(user => {
     // this.user = user
     // console.log(user)
     // console.log(user.displayName)
  //  })

  }

  ngOnInit(): void {
  }

  logout(){
    this.authService.logout();
  }

  isAdmin(){
    // return false;
    return true;
    // this.userService.getUser()
    //   .subscribe(user => {
    //     return user.isAdmin        
    //   });
  }
}
