import React from 'react';
import {
  Avatar,
  Box,
  Button,
  Checkbox,
  Container,
  CssBaseline,
  Divider,
  FormControlLabel,
  Grid,
  TextField,
  Typography,
  Paper
} from '@mui/material';
import GitHubIcon from '@mui/icons-material/GitHub';
import GoogleIcon from '@mui/icons-material/Google';

export default function LoginForm() {
  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <Box
        sx={{
          marginTop: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h1" variant="h5" gutterBottom>
          Welcome!
        </Typography>
        <Typography variant="body2" color="textSecondary" align="center">
          Use these awesome forms to login or create new account in your project for free.
        </Typography>

        <Paper elevation={3} sx={{ mt: 4, p: 4, width: '100%' }}>
          <Typography variant="subtitle2" align="center" gutterBottom>
            Sign in with
          </Typography>
          <Grid container spacing={2} justifyContent="center">
            <Grid item>
              <Button
                variant="outlined"
                startIcon={<GitHubIcon />}
              >
                Github
              </Button>
            </Grid>
            <Grid item>
              <Button
                variant="outlined"
                startIcon={<GoogleIcon />}
              >
                Google
              </Button>
            </Grid>
          </Grid>

          <Divider sx={{ my: 3 }}>Or sign in with credentials</Divider>

          <Box component="form" noValidate>
            <TextField
              margin="normal"
              required
              fullWidth
              label="Email Address"
              name="email"
              autoComplete="email"
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type="password"
              autoComplete="current-password"
            />
            <FormControlLabel
              control={<Checkbox value="remember" color="primary" />}
              label="Remember me"
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 2, mb: 2 }}
            >
              Sign In
            </Button>
            <Grid container justifyContent="space-between">
              <Grid item>
                <Button href="#" size="small">Forgot password</Button>
              </Grid>
              <Grid item>
                <Button href="#" size="small">Create new account</Button>
              </Grid>
            </Grid>
          </Box>
        </Paper>
      </Box>
    </Container>
  );
}
