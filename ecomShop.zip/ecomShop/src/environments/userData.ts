export const UserDetails = {
    production: false ,
    details : { "email" : "rajesh9616@gmail.com",
                "isAdmin" : true,
                "name" : "Rajesh"
             }
  };
  