import './ChartCard.css';

const ChartCard = ({ title, chartType }) => (
  <div className="chart-card">
    <div className="chart-title">{title}</div>
    <div className="chart-box">{chartType} Chart</div>
    <div className="chart-footer">Updated 2 days ago</div>
  </div>
);

export default ChartCard;
